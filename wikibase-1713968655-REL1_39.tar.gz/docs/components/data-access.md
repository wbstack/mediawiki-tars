# Wikibase Data Access

The **data-access** component has been split out of [repo] and [lib] over time.

[repo]: @ref md_docs_components_repo
[lib]: @ref md_docs_components_lib
