declare module 'service-runner';
