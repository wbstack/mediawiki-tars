declare module 'rtl-detect' {
	export default class RtlDetectLib {
		public static getLangDir( code: string ): string;
	}
}
