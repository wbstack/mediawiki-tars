interface Language {
	code: string;
	directionality: string;
}

export default Language;
