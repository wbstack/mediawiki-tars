interface TermboxLinks {
	editLinkUrl: string;
	loginLinkUrl: string;
	signUpLinkUrl: string;
}

export default TermboxLinks;
