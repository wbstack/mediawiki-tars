import ContextError from '@/common/error/ContextError';

export default class MessageNotFound extends ContextError {}
