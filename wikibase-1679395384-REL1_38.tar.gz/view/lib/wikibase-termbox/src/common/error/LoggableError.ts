interface LoggableError {
	getContext(): object;
}

export default LoggableError;
