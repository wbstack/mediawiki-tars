export const LANGUAGE_TRANSLATION_UPDATE = 'translationUpdate';
export const LANGUAGE_UPDATE = 'languageUpdate';
