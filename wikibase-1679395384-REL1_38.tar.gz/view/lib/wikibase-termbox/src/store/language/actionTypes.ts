export const LANGUAGE_INIT = 'languageInit';
export const ENSURE_AVAILABLE_IN_LANGUAGE = 'ensureAvailableInLanguage';
