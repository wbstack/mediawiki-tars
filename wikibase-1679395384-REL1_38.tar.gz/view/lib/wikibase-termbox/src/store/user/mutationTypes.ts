export const LANGUAGE_INIT = 'initializeLanguage';
export const SECONDARY_LANGUAGES_INIT = 'setSecondaryLanguages';
export const USER_SET_NAME = 'setUserName';
export const USER_SET_PREFERENCE = 'setUserPreference';
