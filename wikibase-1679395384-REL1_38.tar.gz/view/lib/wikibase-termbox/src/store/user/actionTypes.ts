export const LANGUAGE_PREFERENCE = 'languagePreference';
export const USER_NAME_SET = 'userSetName';
export const USER_PREFERENCES_INIT = 'userInitPreferences';
export const USER_PREFERENCE_SET = 'userSetPreference';
