export interface Snak {
	equals( snak: Snak ): boolean;
}
