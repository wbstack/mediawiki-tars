export interface Reference {
	equals( reference: Reference ): boolean;
}
