export const GET_STATEMENT_TAINTED_STATE = 'getStatementTaintedState';
export const GET_POPPER_STATE = 'getPopperState';
export const GET_EDIT_STATE = 'getEditState';
export const GET_HELP_LINK = 'getHelpLink';
