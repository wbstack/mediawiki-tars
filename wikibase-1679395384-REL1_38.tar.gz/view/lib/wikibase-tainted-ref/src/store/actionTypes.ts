export const STORE_INIT = 'initStore';
export const STATEMENT_TAINTED_STATE_TAINT = 'taintTaintedState';
export const STATEMENT_TAINTED_STATE_UNTAINT = 'untaintTaintedState';
export const POPPER_SHOW = 'showPopper';
export const POPPER_HIDE = 'hidePopper';
export const HELP_LINK_SET = 'setHelpLink';
export const START_EDIT = 'startStatementEdit';
export const STOP_EDIT = 'stopStatementEdit';
