export default interface StatementsTaintedState {
	[ statementGuid: string ]: boolean;
}
