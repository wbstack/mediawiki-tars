# Wikibase Termbox v2

The Termbox v2 is developed on Wikimedia Gerrit in the [wikibase/termbox] repository.

You may want to read the [README] for more details.

By default all Termbox v2 functionality is disabled.
In order to enable it, please see the [termboxEnabled] setting.

[README]: https://gerrit.wikimedia.org/r/plugins/gitiles/wikibase/termbox/+/master/README.md
[Wikimedia Gerrit]: https://gerrit.wikimedia.org
[wikibase/termbox]: https://gerrit.wikimedia.org/r/plugins/gitiles/wikibase/termbox/
[termboxEnabled]: @ref repo_termboxEnabled
