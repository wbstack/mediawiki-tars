# N) Title (short noun phrase) {#adr_nnnn}

Date: YYYY-MM-DD

## Status

proposed, accepted, rejected, deprecated, superseded, ...

## Context

...

## Decision

...

## Consequences

...
