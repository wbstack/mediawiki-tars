# Wikibase Data Access

The **data-access** component has been split out of [repo] and [lib] over time.

[repo]: @ref docs_components_repo
[lib]: @ref docs_components_lib
