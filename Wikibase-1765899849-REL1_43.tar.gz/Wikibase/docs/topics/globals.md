# Globals

PHP globals used by Wikibase.

[TOC]

#### wgWBRepoSettings {#wgWBRepoSettings}

Settings array for a repository.

See @ref docs_topics_options

#### wgWBClientSettings {#wgWBClientSettings}

Settings array for a client.

See @ref docs_topics_options
