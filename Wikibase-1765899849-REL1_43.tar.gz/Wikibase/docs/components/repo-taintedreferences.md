# Wikibase Tainted References

The Tainted References component spans both View and Repo components and directories.

By default, all tainted references functionality is disabled.
In order to enable it, please see the [taintedReferencesEnabled] setting.

[taintedReferencesEnabled]: @ref repo_taintedReferencesEnabled
