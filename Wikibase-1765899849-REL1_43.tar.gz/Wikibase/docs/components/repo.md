# Wikibase Repository

The **repo** is the extension for the repository. It allows the creation and maintenance of structured data.
This is being used on [wikidata.org].

The extension has multiple sub components:
  - @subpage docs_components_repo-taintedreferences
  - @subpage docs_components_repo-federated-properties

[wikidata.org]: https://www.wikidata.org
