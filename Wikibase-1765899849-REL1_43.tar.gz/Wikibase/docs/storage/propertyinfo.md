# Property Info

A secondary lookup table for information associated with wikibase properties.
This information is derived from the primary data blob describing the property.

You can view the table spec at @ref docs_sql_wb_property_info
