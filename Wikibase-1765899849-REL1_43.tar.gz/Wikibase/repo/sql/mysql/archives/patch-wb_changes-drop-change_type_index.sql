DROP INDEX wb_changes_change_type ON /*_*/wb_changes;
DROP INDEX wb_changes_change_object_id ON /*_*/wb_changes;
DROP INDEX wb_changes_change_user_id ON /*_*/wb_changes;
