# Item Sitelinks

Secondary storage is needed for sitelinks in order to have:
 - Uniqueness of sitelinks across all Wikibase Items.
 - Lookup of an Item using a site global ID and page name.

You can view the table spec at @ref docs_sql_wb_items_per_site
