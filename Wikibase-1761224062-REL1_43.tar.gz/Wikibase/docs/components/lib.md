# Wikibase Lib

The **lib** bundles common code that is used by both the @ref docs_components_client and the @ref docs_components_repo.

### Brief history of this extension

Overtime this extension has turned into a kitchen sink of things.
The long term plan is to remove this extension in favour of more focused modules.

* 2015 - [Removal of serializers from lib](https://addshore.com/2015/08/removing-use-of-mediawikis-api-rawmode-in-wikibase/)
* 2014 - The test was [renamed to NoBadDependencyUsageTest](https://gerrit.wikimedia.org/r/#/q/I43a7f34ed1bd5be99becaad8338a3ba59f500284)
* 2013 - [NoClientOrRepoUsageTest was introduced](https://gerrit.wikimedia.org/r/#/q/Ia875be04ac551ce7e947188c5f3e34e663a7b060)
