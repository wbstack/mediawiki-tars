# Wikibase Client

The **client** is the extension for the client.
It allows several MediaWiki instances to use data provided by a Wikidata instance.
Usually, you would not use them in a single wiki.
This is being used on the Wikipedias.

The extension has multiple sub components:
  - @subpage docs_components_client-databridge
