export default interface StatementsPopperIsOpen {
	[ statementGuid: string ]: boolean;
}
