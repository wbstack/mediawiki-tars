export const NS_ENTITY = 'entity';
export const NS_USER = 'user';
export const NS_LANGUAGE = 'language'; // this one is also hard-coded in inlanguage.js
export const NS_LINKS = 'links';
export const NS_MESSAGES = 'messages';
