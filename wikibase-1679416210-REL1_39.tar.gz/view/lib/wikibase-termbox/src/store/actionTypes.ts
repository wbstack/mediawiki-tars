export const EDITMODE_ACTIVATE = 'activateEditMode';
export const EDITMODE_DEACTIVATE = 'deactivateEditMode';
