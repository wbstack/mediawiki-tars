export const MESSAGES_INIT = 'initializeMessages';
