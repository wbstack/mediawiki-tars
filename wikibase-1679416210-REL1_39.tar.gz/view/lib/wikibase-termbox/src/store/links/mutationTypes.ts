export const LINKS_UPDATE = 'updateLinks';
