export const ENTITY_INIT = 'entityInit';
export const ENTITY_SAVE = 'entitySave';
export const ENTITY_ALIASES_EDIT = 'EntityEditAliases';
export const ENTITY_ALIAS_REMOVE = 'EntityRemoveAlias';
export const ENTITY_LABEL_EDIT = 'entityEditLabel';
export const ENTITY_DESCRIPTION_EDIT = 'editEntityDescription';
export const ENTITY_ROLLBACK = 'entityRollback';
