import ServiceRunner from 'service-runner';
new ServiceRunner().start();
