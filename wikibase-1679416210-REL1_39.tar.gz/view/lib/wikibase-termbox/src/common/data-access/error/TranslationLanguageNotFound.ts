import ContextError from '@/common/error/ContextError';

export default class TranslationLanguageNotFound extends ContextError {}
