import Language from './Language';

interface LanguageCollection {
	[code: string]: Language;
}

export default LanguageCollection;
