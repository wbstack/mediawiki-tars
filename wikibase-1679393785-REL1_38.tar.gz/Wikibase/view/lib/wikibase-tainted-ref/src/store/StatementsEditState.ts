export default interface StatementsEditState {
	[ statementGuid: string ]: boolean;
}
