export interface SnakList {
	equals( snakList: SnakList ): boolean;
}
