import ContextError from '@/common/error/ContextError';

export default class TechnicalProblem extends ContextError {}
