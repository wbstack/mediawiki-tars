import ContextError from '@/common/error/ContextError';

export default class EntityNotFound extends ContextError {}
