export enum Hooks {
	entityLoaded = 'wikibase.entityPage.entityLoaded',
}
