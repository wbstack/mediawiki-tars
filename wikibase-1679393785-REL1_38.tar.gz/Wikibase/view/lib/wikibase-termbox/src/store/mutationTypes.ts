export const EDITMODE_SET = 'setEditMode';
