export const ENTITY_UPDATE = 'updateEntity';
export const EDITABILITY_UPDATE = 'updateEditability';
export const ENTITY_SET_ALIASES = 'editEntityAliases';
export const ENTITY_REMOVE_ALIAS = 'removeEntityAlias';
export const ENTITY_SET_LABEL = 'editEntityLabel';
export const ENTITY_SET_DESCRIPTION = 'setEntityDescription';
export const ENTITY_REVISION_UPDATE = 'updateRevision';
export const ENTITY_ROLLBACK = 'entityRollback';
