import MessageTranslationCollection from '@/datamodel/MessageTranslationCollection';

interface Messages {
	messages: MessageTranslationCollection;
}

export default Messages;
