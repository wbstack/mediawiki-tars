<?php

namespace Wikibase\Lib\Store;

use RuntimeException;

/**
 * @license GPL-2.0-or-later
 * @author Lucie-Aimée Kaffee
 */
class PropertyOrderProviderException extends RuntimeException {

}
