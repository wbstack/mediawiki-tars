<?php

namespace Wikibase\Lib\Store;

use MWContentSerializationException;

/**
 * @license GPL-2.0-or-later
 * @author Noa Rave
 */
class EntityContentTooBigException extends MWContentSerializationException {

}
