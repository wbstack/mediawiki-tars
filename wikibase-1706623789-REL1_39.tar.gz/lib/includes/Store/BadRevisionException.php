<?php

namespace Wikibase\Lib\Store;

/**
 * @license GPL-2.0-or-later
 * @author Daniel Kinzler
 */
class BadRevisionException extends StorageException {

}
