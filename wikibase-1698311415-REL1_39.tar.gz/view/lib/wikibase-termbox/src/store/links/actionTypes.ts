export const LINKS_INIT = 'linksInit';
