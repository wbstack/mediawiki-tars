interface LinksState {
	editLinkUrl: string;
	loginLinkUrl: string;
	signUpLinkUrl: string;
}

export default LinksState;
