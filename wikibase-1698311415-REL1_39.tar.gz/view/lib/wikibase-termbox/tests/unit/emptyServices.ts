const emptyServices = {
	get: jest.fn(),
};

export default emptyServices;
