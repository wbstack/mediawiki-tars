<?php

namespace Wikibase\View\Termbox\Renderer;

/**
 * @license GPL-2.0-or-later
 */
class TermboxNoRemoteRendererException extends TermboxRenderingException {
}
