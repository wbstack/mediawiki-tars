<?php

namespace Wikibase\View\Termbox\Renderer;

use RuntimeException;

/**
 * @license GPL-2.0-or-later
 */
class TermboxRenderingException extends RuntimeException {
}
