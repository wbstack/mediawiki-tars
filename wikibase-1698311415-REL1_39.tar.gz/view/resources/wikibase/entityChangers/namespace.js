( function ( wb ) {
	'use strict';

	wb.entityChangers = {};
}( wikibase ) );
