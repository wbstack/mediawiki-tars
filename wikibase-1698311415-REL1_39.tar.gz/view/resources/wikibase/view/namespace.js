( function ( wb ) {
	'use strict';

	wb.view = wb.view || {};
}( wikibase ) );
