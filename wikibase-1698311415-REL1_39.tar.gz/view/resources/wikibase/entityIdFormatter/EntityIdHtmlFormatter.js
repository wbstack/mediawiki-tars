( function () {
	'use strict';

	var SELF = function () {};

	SELF.prototype.format = util.abstractMember;

	module.exports = SELF;

}() );
